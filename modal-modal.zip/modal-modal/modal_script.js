var modal = ".modal-window";
var dimmer = "#dimmer";
var callback = ".callback";
// открытие и закрытие окна
$(document).ready(function () {

	$( "#call" ).click(function() {
	  $(dimmer).fadeIn("slow");
	  $(modal).fadeIn("slow");
	});
	$(dimmer).click(function(){
		closeWindow();
	});

	$(".fa.fa-times").click(function(){
		closeWindow();
	});

	$("body").on("keydown", function(e) { 
		if (e.keyCode == 27) { 
			closeWindow(); 
		} 
	}); 

});

// форма отправки ajax

$(document).ready(function () {
	$(".modal-form").submit(function () {
		
		// Получение ID формы
		var formID = $(this).attr('class');
		// Добавление решётки к имени ID
		var formNm = $('.' + formID);

		$.ajax({
			type: "POST",
			url: '/webmashina_callback/modal_send_mail.php',
			data: formNm.serialize(),
			success: function (data) {
				// Вывод текста результата отправки
				$(formNm).html(data);
				SetTimeout(function() {
					closeWindow();
				}, 3500);
			},
			error: function (jqXHR, text, error) {
				// Вывод текста ошибки отправки
				$(formNm).html(error);
			}
		});

		return false;
	});
});
	
function closeWindow(){
	$(dimmer).fadeOut("slow");
	$(modal).fadeOut("slow");
}
