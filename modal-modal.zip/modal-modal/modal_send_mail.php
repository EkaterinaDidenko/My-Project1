<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['name'])) {$name = strip_tags(trim($_POST['name']));}
    if (isset($_POST['phone'])) {$phone = strip_tags(trim($_POST['phone']));}
    if (isset($_POST['header'])) {$header = strip_tags(trim($_POST['header']));}
 
    /*Укажите адрес, на который должно приходить письмо*/
    $to = "the9thlaw@ukr.net"; 
    /*Укажите адрес, с которого будет приходить письмо, можно не настоящий, нужно для формирования заголовка письма*/
    $sendfrom = "Sprint-dental"; 
    
    $headers  = "From: " . strip_tags($sendfrom) . "<sprint-dental@sprint-dental.com.ua>\r\n";
    $headers .= "Reply-To: ". strip_tags($sendfrom) . "\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html;charset=utf-8 \r\n";
    $subject = $header;
    $message = "<b>Имя:</b> $name <br/>\r\n
                <b>Телефон:</b> $phone";

    $send = mail ($to, $subject, $message, $headers);
    if ($send == 'true') {
        echo '<center>Спасибо за отправку вашего сообщения! Для повторной отправки перезагрузите страницу</center>';
    }
    else {
        echo '<center><b>Ошибка. Сообщение не отправлено! Для повторной отправки перезагрузите страницу</b></center>';
    }
} else {
    http_response_code(403);
    echo "Попробуйте еще раз";
} ?>